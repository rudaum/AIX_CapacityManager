#!/usr/bin/python
# - Purpose:
#       To convert range of dates
# - Author:
#       Rudolf Wolter
# - Contact for questions and/or comments:
#       rudolf.wolter@kuehne-nagel.com
# - Parameters:
#       < accepted arguments>
# - Version Releases and modifications.
#       <versions history log>

### START OF MODULE IMPORTS
# --------------------------------------------------------------- #
from os import path, system
from sys import path as libpath
from datetime import time, datetime
from subprocess import Popen, PIPE
from collections import OrderedDict
from optparse import OptionParser
libpath.insert(0, 'lib')
#from dblib import Vmstat, mk_dbbenv
# --------------------------------------------------------------- #
### END OF MODULE IMPORTS

### START OF GLOBAL VARIABLES DECLARATION
# --------------------------------------------------------------- #
PEAKSTART = time(8, 00)
PEAKSTOP = time(20, 00)
TRESHOLDW = 20
TRESHOLDC = 8
INTERVAL = 6  # INTERVAL x 10 sec / 60 = Minutes
VMSTATSOURCEDIR = '/ib/dat/kn/statistic/vmstat'
LPARSTATSOURCEDIR = '/admin/stats/lparstat'
REPORTDIR = path.dirname(path.realpath(__file__)) + '/reports'
BASELINE = ['sindbad', 'ibaz', 'parisade', 'ibcomtest',
            'salomo', 'alibaba', 'maruf', 'ibedi1', 'ibedi2',
            'ibedi3', 'ibedi4', 'ibcom1', 'ibcom2', 'ibcom3']
# --------------------------------------------------------------- #
### END OF GLOBAL VARIABLES DECLARATION\

### START OF FUNCTIONS DECLARATION
# --------------------------------------------------------------- #
def parse_args():
    """
    Purpose:
        To parse the scripts given arguments and to generate a dictionary with the values.
    Returns:
        options: A Dictionary with all given, validated arguments.
    Parameters:
    """
    parser = OptionParser(usage='-h | -s [ ALL | servername ]')

    # Declaring Arguments
    parser.add_option("-s", "--server", dest="server",
                      help="ALL to retrieve from all servers or server name to retrieve from a singular server")

    (opts, pargs) = parser.parse_args()
    if not opts.server:
        parser.error('Server Name not given. Use ALL for all servers or provide a single name')

    # if not particular server is given, retrieve from ALL
    if vars(opts)['server'].lower() == 'all':
        return BASELINE
    else:
        return eval("['" + (vars(opts)['server']) + "']")
# --------------------------------------------------------------- #
# --------------------------------------------------------------- #
def retrieve_files(_server):
    """
    Purpose:
        To retrieve vmstat files from a server
    Returns:
        options: A Dictionary with all given, validated arguments.
    Parameters:
        server - Server where the files will be retrieved
    """
    # Retrieving vmstat data
    print('Trying to retrieve vmstat files from {} ...'.format(_server))
    system("/usr/bin/rsync -avz {}:{}/*.dat* {}/{}/ 2>/dev/null".format(server, VMSTATSOURCEDIR, REPORTDIR, _server))
    print('Success!')

    # Retrieving lparstat data
    print('Trying to retrieve lparstat files from {} ...'.format(_server))
    system("/usr/bin/rsync -avz {}:{}/*.dat* {}/{}/ 2>/dev/null".format(_server, LPARSTATSOURCEDIR, REPORTDIR, _server))
    print('Success!')

    # Decompressing Any dat.gz files
    print('Decompressing any compressed files ...')
    cmd = 'find {}/{} -type f -name "*.dat.gz" -exec  gzip -kfd {}'.format(REPORTDIR, _server, "{} \;")
    system(cmd)
    print('Success!')
# --------------------------------------------------------------- #
# --------------------------------------------------------------- #
def select_files(_server, filetype, newerthan=15):
    """
    Purpose:
        To select the vmstat files from a server that are newer than 'newerthan'
    Returns:
        options: A list of files selected after the conditions
    Parameters:
        server - in which server te files should be selected
        newerthan- files newer than this will be selected. Default 31 days
    """
    print('Decompressing any compressed files ...')
    cmd = 'find {}/{} -mtime -{} -type f -name "{}*.dat.gz" -exec  gzip -kfd {}'\
          .format(REPORTDIR, _server, newerthan, filetype, "{} \;")
    system(cmd)
    print('Success!')

    print('Selecting {} files newer than {} days for {} ...'.format(filetype, newerthan, _server))
    cmd = 'find {}/{} -mtime -{} -type f -name "{}*.dat"'.format(REPORTDIR, _server, newerthan, filetype)
    vmstatfiles = []
    for vmstat_file in Popen(cmd, stdin=PIPE, stdout=PIPE, shell=True).stdout.readlines():
        vmstatfiles.append(vmstat_file.replace('\n', ''))

    print('Success!')
    return vmstatfiles
# --------------------------------------------------------------- #

# --------------------------------------------------------------- #
def mk_vmstatlist(_server, _vmstat_files):
    """
        Purpose:
            To create a single data file containing a "dump" of a List, so it can be read by the Report Generator.
        Returns:
            N/A
        Parameters:
            _server - The server the vmstat files were collected from
            _vmstat_files - A List of previously selected vmstat files
        """
    days = OrderedDict()

    serverdir = REPORTDIR + "/" + _server

    cmd = '/usr/bin/ls {}/vmstat*.dat'.format(serverdir)
    #for vmstat_file in Popen(cmd, stdin=PIPE, stdout=PIPE, shell=True).stdout.readlines():
    for vmstat_file in _vmstat_files:
        vmstat_file = vmstat_file.strip('\n')
        pholder, srvname, d8 = path.basename(vmstat_file).strip('.dat').split('_')
        d8 = datetime.strptime(d8, '%Y%m%d')
        # Only considers Weekdays
        if d8.weekday() < 5:
            print('Processing {}'.format(vmstat_file))
            # Grepping $1=Run Queue, $17=idle CPU
            cmd = "grep ':' " + vmstat_file + " | egrep -v 'System configuration' | awk '{print $17, $NF}'"
            output = Popen(cmd, stdin=PIPE, stdout=PIPE, shell=True).stdout.readlines()
            samples = []
            customsamples = []
            tsholdw = []
            tsholdc = []
            day = d8.strftime('%d-%m-%Y')
            days[day] = []

            for count, item in enumerate(output):
                idle, timestamp = item.split(' ')
                idle = int(idle)
                h, m, s = [int(x) for x in timestamp.strip().split(':')]
                timestamp = time(h, m, s)

                # Only consider Business Hours
                if PEAKSTART <= timestamp <= PEAKSTOP:
                    customsamples.append(idle)
                    if idle <= TRESHOLDW:
                        tsholdw.append((idle, timestamp.strftime('%H:%M:%S')))
                    if idle <= TRESHOLDC:
                        tsholdc.append((idle, timestamp.strftime('%H:%M:%S')))
                    if count % INTERVAL == 0:
                        cs = round(sum(customsamples, 0.00) / len(customsamples), 2)
                        samples.extend(customsamples)
                        days[day].append((timestamp.strftime('%H:%M:%S'), cs))
                        customsamples = []
            try:
                avgthshw = round(len(tsholdw) / round(len(samples), 2) * 100, 2)
                avgthshc = round(len(tsholdc) / round(len(samples), 2) * 100, 2)
                avgday = 100 - (round(sum(samples, 0.00) / len(samples), 2))
                overall.append((day, avgday, avgthshw, avgthshc))

            except ZeroDivisionError:
                print 'Vmstat data not found for file {}:'.format(vmstat_file.strip())
    print overall[0][0] + "_" + overall[len(overall)-1][0]
    listfile = open(REPORTDIR + '/' + _server + '/' + _server + '_vmstat.list', 'w')
    listfile.write(str(overall))
    listfile.close()
# --------------------------------------------------------------- #
# --------------------------------------------------------------- #
def mk_lparstatlist(_server, lparstat_files):
    """
        Purpose:
            To create a single data file containing a "dump" of a List, so it can be read by the Report Generator.
        Returns:
            N/A
        Parameters:
            _server - The server the vmstat files were collected from
            _vmstat_files - A List of previously selected vmstat files
        """
    days = OrderedDict()

    for lparstat_file in lparstat_files:
        pholder, srvname, d8 = path.basename(lparstat_file).strip('.dat').split('_')
        d8 = datetime.strptime(d8, '%Y%m%d')
        # Only considers Weekdays
        if d8.weekday() < 5:
            print('Processing {}'.format(lparstat_file))
            # Grepping $1=Run Queue, $17=idle CPU
            cmd = "grep ':' " + lparstat_file + " | egrep -v 'System configuration' | awk '{print $17, $NF}'"
            output = Popen(cmd, stdin=PIPE, stdout=PIPE, shell=True).stdout.readlines()
            samples = []
            customsamples = []
            tsholdw = []
            tsholdc = []
            day = d8.strftime('%d-%m-%Y')
            days[day] = []

            for count, item in enumerate(output):
                idle, timestamp = item.split(' ')
                idle = int(idle)
                h, m, s = [int(x) for x in timestamp.strip().split(':')]
                timestamp = time(h, m, s)

                # Only consider Business Hours
                if PEAKSTART <= timestamp <= PEAKSTOP:
                    customsamples.append(idle)
                    if idle <= TRESHOLDW:
                        tsholdw.append((idle, timestamp.strftime('%H:%M:%S')))
                    if idle <= TRESHOLDC:
                        tsholdc.append((idle, timestamp.strftime('%H:%M:%S')))
                    if count % INTERVAL == 0:
                        cs = round(sum(customsamples, 0.00) / len(customsamples), 2)
                        samples.extend(customsamples)
                        days[day].append((timestamp.strftime('%H:%M:%S'), cs))
                        customsamples = []
            try:
                avgthshw = round(len(tsholdw) / round(len(samples), 2) * 100, 2)
                avgthshc = round(len(tsholdc) / round(len(samples), 2) * 100, 2)
                avgday = 100 - (round(sum(samples, 0.00) / len(samples), 2))
                overall.append((day, avgday, avgthshw, avgthshc))

            except ZeroDivisionError:
                print 'Vmstat data not found for file {}:'.format(lparstat_file.strip())
    listfile = open(REPORTDIR + '/' + _server + '/' + _server + '_lparstat.list', 'w')
    listfile.write(str(overall))
    listfile.close()
# --------------------------------------------------------------- #
### END OF FUNCTIONS DECLARATION

### START OF CLASS DEFINITIONS
# --------------------------------------------------------------- #
# --------------------------------------------------------------- #
### END OF CLASS DEFINITIONS


### START OF MAIN PROGRAM
serverlist = parse_args()
# mk_dbbenv()

for server in serverlist:
    print('Generating reports for {} ... It may take a while.'.format(server))
    overall = []

    # --- Retrieving STAT files from remove servers
    #retrieve_files(server)

    # --- Processing VMSTAT files
    vmstat_files = select_files(server, 'vmstat')
    mk_vmstatlist(server, vmstat_files)

    # --- Processing LPARSTAT files
    files = select_files(server, 'lparstat')
    print files

print('Success!')
### END OF MAIN PROGRAM
