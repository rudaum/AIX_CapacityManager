#!/usr/bin/python
# - Purpose:
#       To convert range of dates
# - Author:
#       Rudolf Wolter
# - Contact for questions and/or comments:
#       rudolf.wolter@kuehne-nagel.com
# - Parameters:
#       < accepted arguments>
# - Version Releases and modifications.
#       <versions history log>

### START OF MODULE IMPORTS
# --------------------------------------------------------------- #
from os import path
from openpyxl import Workbook
from openpyxl.drawing.line import LineProperties
from openpyxl.drawing.colors import ColorChoice
from openpyxl.chart import Series, LineChart, Reference
from openpyxl.chart.layout import Layout, ManualLayout
from openpyxl.chart.trendline import Trendline, GraphicalProperties
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
from optparse import OptionParser
# --------------------------------------------------------------- #
### END OF MODULE IMPORTS

### START OF GLOBAL VARIABLES DECLARATION
# --------------------------------------------------------------- #
PEAKSTART = '08:00'
PEAKSTOP = '20:00'
TRESHOLDW = 20
TRESHOLDC = 8
VMSTATLOCALDIR = path.dirname(path.realpath(__file__)) + '/reports'
WORKBOOKNAME = path.dirname(path.realpath(__file__)) + '/SomethingWentBad.xlsx'
BASELINE = ['sindbad', 'ibaz', 'parisade', 'ibcomtest',
            'salomo', 'alibaba', 'maruf', 'ibedi1', 'ibedi2',
            'ibedi3', 'ibedi4', 'ibcom1', 'ibcom2', 'ibcom3']
BGCOLOR = '8CB4E2'
FONTCOLOR = '000000'
FONTNAME = 'Arial Unicode MS'
BORDER = Border(
            left=Side(border_style='double'),
            right=Side(border_style='double'),
            top=Side(border_style='double'),
            bottom=Side(border_style='double')
        )
# --------------------------------------------------------------- #
### END OF GLOBAL VARIABLES DECLARATION\

### START OF FUNCTIONS DECLARATION
# --------------------------------------------------------------- #
def parse_args():
    """
    Purpose:
        To parse the scripts given arguments and to generate a dictionary with the values.
    Returns:
        options: A Dictionary with all given, validated arguments.
    Parameters:
    """
    parser = OptionParser(usage='-h | -s [ ALL | servername ]')

    # Declaring Arguments
    parser.add_option("-s", "--server", dest="server",
                      help="ALL to retrieve from all servers or server name to retrieve from a singular server")

    (opts, pargs) = parser.parse_args()
    if not opts.server:
        parser.error('Server Name not given. Use ALL for all servers or provide a single name')

    # if not particular server is given, use ALL
    global WORKBOOKNAME
    if vars(opts)['server'].lower() == 'all':
        WORKBOOKNAME = path.dirname(path.realpath(__file__)) + '/all_lpars_perfreport.xlsx'
        return BASELINE
    else:
        WORKBOOKNAME = path.dirname(path.realpath(__file__)) + '/' + vars(opts)['server'] + '_perfreport.xlsx'
        return eval("['" + (vars(opts)['server']) + "']")
# --------------------------------------------------------------- #
# --------------------------------------------------------------- #
def mk_readme_sheet(wb):
    """
    Purpose:
        To create a README sheet with useful information about the other graphs.

    Parameters:
        wb - The current Workbook
    """
    ws = wb.worksheets[0]
    ws.title = 'README'
    # "Coloring" the sheet's background, to hide the data.
    area = Reference(ws, min_col=1, min_row=1, max_row=60, max_col=40)
    for cell in area.cells:
        ws[cell].fill = PatternFill(bgColor=BGCOLOR, fgColor=BGCOLOR, fill_type="solid")
        ws[cell].font = Font(name=FONTNAME, color=FONTCOLOR, size=12)

    # Setting Columns size ---
    ws.column_dimensions['B'].width = 96
    # ---

    # Information Block ---
    ws['B2'].font = Font(name="Arial Black", size=14)
    ws['B2'].value = 'About This:'
    ws['B3'].border = BORDER
    ws['B3'].alignment = Alignment(wrapText=True)
    ws['B3'].value = '    The Charts are generated from daily averages of 10-seconds interval snapshot samples, ' \
                     'that were collected during week days and during Peak Business Hours ({} - {} CEST). ' \
                     'Each sheet contains Charts for one or more Servers. ' \
                     'Note that weekends will not be included in the charts.'.format(PEAKSTART, PEAKSTOP)
    # ---

    # CPU_Relative Block ---
    ws['B5'].font = Font(name="Arial Black", size=14)
    ws['B5'].value = 'CPU_Relative Explained:'
    ws['B6'].border = BORDER
    ws['B6'].alignment = Alignment(wrapText=True)
    ws['B6'].value = "    The Charts represents the daily averages of 4 measures:\n" \
                     "- 'Average Busy': The average of the CPU utilisation of that day. ex. 60 would mean that " \
                     "the server had an average of 60% of CPU utilisation during business hours for that day.\n" \
                     "- 'Linear(Average Busy)': A Linear trend generated from the Average Busy of all days.\n" \
                     "- '% of Samples above {}% Cpu Usage': Represents an average the percentage of Samples collected" \
                     " of which the CPU utilisation were above {}%.\n" \
                     "- '% of Samples above {}% Cpu Usage': Represents an average the percentage of Samples collected" \
                     " of which the CPU utilisation were above {}%, it doesn't count the {}% samples."\
                     .format(100 - TRESHOLDW, 100 - TRESHOLDW, 100 - TRESHOLDC, 100 - TRESHOLDC, 100 - TRESHOLDW)
    # ---
# --------------------------------------------------------------- #

# --------------------------------------------------------------- #
def mk_cpurelative_sheet(wb, _serverlist):
    """
    Purpose:
        To create the Workbook(excel file) with Relative CPU usage graphs using the data gathered from vmstat

    Parameters:
        wb - The current Workbook
        serverlist - a list of servers that the graph will be generated
    """
    # --- 'CPU' Sheet
    ws = wb.create_sheet('CPU_Relative')
    looprow = 1
    loopcol = 1  # increases in 4 columns for each server
    graphpos = 2  # Which row to place the First Graph

    for server in _serverlist:
        print('Generating reports for {} ...'.format(server))
        ws.cell(row=1, column=loopcol, value='Date')
        ws.cell(row=1, column=loopcol + 1, value='Average Busy')
        ws.cell(row=1, column=loopcol + 2, value='% of Samples above {}% Cpu Usage'.format(100 - TRESHOLDW))
        ws.cell(row=1, column=loopcol + 3, value='% of Samples above {}% Cpu Usage'.format(100 - TRESHOLDC))

        # Reading the Vmstat List File
        samples = eval(open(VMSTATLOCALDIR + '/' + server + '/' + server + '_vmstat.list', 'r').read())
        print samples[0][0] + "_" + samples[len(samples) - 1][0]
        i = looprow
        for date, average, warning, critical in samples:
            i = i + 1
            ws.cell(row=i, column=loopcol, value=date)
            ws.cell(row=i, column=loopcol + 1, value=average)
            ws.cell(row=i, column=loopcol + 2, value=warning)
            ws.cell(row=i, column=loopcol + 3, value=critical)

        # --- Setting Chart Properties
        chart = LineChart()
        chart.title = '{} CPU Usage'.format(server)
        chart.style = 3
        chart.x_axis.number_format = 'dd/mm'
        chart.x_axis.majorTimeUnit = "days"
        chart.height = 10
        chart.width = 26
        chart.legend.position = "t"
        chart.legend.layout = Layout(manualLayout=ManualLayout(yMode='edge', xMode='edge', h=0.1, w=0.8))
        chart.plot_area.layout = Layout(manualLayout=ManualLayout(yMode='edge', xMode='edge'))

        # --- Looping over Columns to build the Chart
        # columns Average, Warning and Critical
        for col in range(loopcol + 1, loopcol + 4):
            values = Reference(ws, min_col=col, min_row=1, max_row=i)
            series = Series(values, title_from_data=True)  # creating the Serie
            chart.series.append(series)

        # Creating Trend
        chart.series[0].trendline = Trendline()

        # --- Setting Plot Area Format
        # Formatting Series
        chart.series[0].graphicalProperties.line = LineProperties(solidFill=ColorChoice(prstClr='green'))
        chart.series[1].graphicalProperties.line = LineProperties(solidFill=ColorChoice(prstClr='orange'))
        chart.series[2].graphicalProperties.line = LineProperties(solidFill=ColorChoice(prstClr='red'))

        # Formatting Trend Line
        chart.series[0].trendline.graphicalProperties = GraphicalProperties()
        chart.series[0].trendline.graphicalProperties.line.solidFill = ColorChoice(prstClr='purple')

        # Setting the 'date' x-axis
        dates = Reference(ws, min_col=loopcol, min_row=2, max_row=i)
        chart.set_categories(dates)

        loopcol = loopcol + 4

        # Adding the Chart
        ws.add_chart(chart, "A{}".format(graphpos))
        graphpos = graphpos + 19

    # "Coloring" the sheet's background, to hide the data.
    area = Reference(ws, min_col=1, min_row=1, max_row=graphpos + 60, max_col=40)
    for cell in area.cells:
        ws[cell].fill = PatternFill(bgColor=BGCOLOR, fgColor=BGCOLOR, fill_type="solid")
        ws[cell].font = Font(color=BGCOLOR)
# --------------------------------------------------------------- #
### END OF FUNCTIONS DECLARATION

### START OF CLASS DEFINITIONS
# --------------------------------------------------------------- #
# --------------------------------------------------------------- #
### END OF CLASS DEFINITIONS


### START OF MAIN PROGRAM
serverlist = parse_args()

# creating the Excel Workbook ...
workbook = Workbook()

# Creating the README sheet
mk_readme_sheet(workbook)

# Creating the Relative CPU usage Sheet
mk_cpurelative_sheet(workbook, serverlist)

# saving the workbook
workbook.save(WORKBOOKNAME)
workbook.close()
print ('{} created successfully'.format(WORKBOOKNAME))
### END OF MAIN PROGRAM
