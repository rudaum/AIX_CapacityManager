#!/usr/bin/python
"""
- Purpose:
    A Library to Handle DB Transactions, mapped as Table -> Class ->  Object by SQLAlchemy

- Author:
    Rudolf Wolter (KN OSY Team)

- Contact for questions and/or comments:
    rudolf.wolter@kuehne-nagel.com

- Version Releases and modifications.
    > 1.0 (18.10.2018) - Initial release with core functionalities.

- TODO:

"""
### START OF MODULE IMPORTS
# --------------------------------------------------------------- #
from collections import OrderedDict
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import text
# --------------------------------------------------------------- #
### END OF MODULE IMPORTS
## DB Section
DBURI = "mysql://cruser:q1w2e3r4@denotsl90.int.kn/crdb"
# DBURI = "mysql://cruser:q1w2e3r4@localhost/crdb"
DBENGINE = create_engine(DBURI)
DBASE = declarative_base()
DBSession = sessionmaker(bind=DBENGINE)()

### START OF FUNCTIONS DECLARATION
# --------------------------------------------------------------- #
# --------------------------------------------------------------- #
def mk_dbbenv():
    DBASE.metadata.create_all(DBENGINE)
# --------------------------------------------------------------- #

# --------------------------------------------------------------- #
def select_all_from(_class):
    """
    Purpose:
        Retrieves all entries from Database for a given Class/Table and stores it in a Dictionary

    Parameters:
    """
    resul_dict = OrderedDict()
    # Feeding the dictionary with the already exisit servers records.
    for entry in eval('DBSession.query({}).order_by({}.name)'.format(_class, _class)):
        resul_dict[entry.name] = entry

    return resul_dict
# --------------------------------------------------------------- #

def destroy_table(_class):
    """
    Purpose:
        ** CAUTION ** This WILL destroy the Representative's Table and all its contents!
    Parameters:
    """
    global DBSession
    DBSession.execute(text('SET FOREIGN_KEY_CHECKS = 0;'))
    DBSession.close()
    _class.__table__.drop(DBENGINE)
    DBSession = sessionmaker(bind=DBENGINE)()
    DBSession.execute(text('SET FOREIGN_KEY_CHECKS = 1;'))
# --------------------------------------------------------------- #

# --------------------------------------------------------------- #
### END OF FUNCTIONS DECLARATION

# --------------------------------------------------------------- #
class Vmstat(DBASE):
    """
    Purpose:
        Represents an AIX Server
    """
    __tablename__ = 'vmstat'
    # Here we define columns for the table servers
    # Notice that each column is also a normal Python instance attribute.
    id = Column(String(64), primary_key=True)
    servername = Column(String(20), nullable=False)
    date = Column(DateTime, nullable=False)
    runqueue = Column(Integer)
    avm = Column(Integer)
    freemem = Column(Integer)
    average_busy = Column(Float)
    average_warning = Column(Float)
    average_critical = Column(Float)

    def self_destruct(self):
        """
        Purpose:
            ** CAUTION ** This WILL destroy the Representative's Table and all its contents!
        Parameters:
        """
        self.__table__.drop(DBENGINE)

    def self_create(self):
        """
        Purpose:
            Creates the Representative's Table
        Parameters:
        """
        self.__table__.create(DBENGINE)

    def get_objvalue(self, column):
        """
        Purpose:
            Retrieves the current value of this instance's column's value. But not from the DB
        Parameters:
            column: The Columns's value to be retrieved.
        """
        return getattr(self, column)

    def get_dbvalue(self):
        """
        Purpose:
            Retrieves the values of a columns direct from the DB
        Parameters:
        """
        return self.__table__.columns.keys()

    def select_by(self, attr_name, attr_value):
        """
        Purpose:
            Queries the Database for all entries that match single Attribute and returns a list of results
        """
        query = eval('DBSession.query({}).filter({}.{} == "{}")'
                     .format(type(self).__name__, type(self).__name__, attr_name, attr_value))
        return query.all()

    def update(self):
        """
        Purpose:
            Updates and commits the database with the currenct Object Instance's Values
        """
        DBSession.add(self)
        DBSession.commit()

    def query(self, custom_query):
        query = eval('DBSession.query({}).filter({})').format(type(self).__name__, custom_query)
        return query.all()

    def query_all(self):
        """
        Purpose:
            Retrieves all entries related to this Class from Database and stores it in an Ordered Dictionary of Objects

        Parameters:
        """
        hostsdict = OrderedDict()
        # Feeding the dictionary with the already exists servers records.
        for entry in DBSession.query(type(self)).order_by(type(self).id):
            hostsdict[entry.id] = entry
        return hostsdict
# --------------------------------------------------------------- #
