#!/usr/bin/python
# - Purpose:
#       To convert range of dates
# - Author:
#       Rudolf Wolter
# - Contact for questions and/or comments:
#       rudolf.wolter@kuehne-nagel.com
# - Parameters:
#       < accepted arguments>
# - Version Releases and modifications.
#       <versions history log>

### START OF MODULE IMPORTS
# --------------------------------------------------------------- #
from os import path
from openpyxl import Workbook, drawing
from openpyxl.chart import Series, LineChart, Reference
from openpyxl.chart.layout import Layout, ManualLayout
from openpyxl.chart.trendline import Trendline, GraphicalProperties
from optparse import OptionParser
# --------------------------------------------------------------- #
### END OF MODULE IMPORTS

### START OF GLOBAL VARIABLES DECLARATION
# --------------------------------------------------------------- #
TRESHOLDW = 20
TRESHOLDC = 8
VMSTATLOCALDIR = path.dirname(path.realpath(__file__)) + '/reports'
WORKBOOKNAME = path.dirname(path.realpath(__file__)) + '/SomethingWentBad.xlsx'
BASELINE = ['sindbad', 'ibaz', 'parisade', 'ibcomtest',
            'salomo', 'alibaba','maruf', 'ibedi1', 'ibedi2',
            'ibedi3','ibedi4', 'ibcom1', 'ibcom2', 'ibcom3']
# --------------------------------------------------------------- #
### END OF GLOBAL VARIABLES DECLARATION\

### START OF FUNCTIONS DECLARATION
# --------------------------------------------------------------- #
def parse_args():
    """
    Purpose:
        To parse the scripts given arguments and to generate a dictionary with the values.
    Returns:
        options: A Dictionary with all given, validated arguments.
    Parameters:
    """

    # parser = OptionParser(usage='-h | [ -d "directory with vmstat files" ] [ -s server ]')
    parser = OptionParser(usage='-h | -s [ ALL | servername ]')

    # Declaring Arguments
    # parser.add_option("-d", "--directory", dest="directory", help="A directory containing one or more vmstat files.")
    parser.add_option("-s", "--server", dest="server",
                      help="ALL to retrieve from all servers or server name to retrieve from a singular server")

    (opts, pargs) = parser.parse_args()
    #if not opts.directory:
    #    parser.error('Vmstat directory not given')
    if not opts.server:
        parser.error('Server Name not given. Use ALL for all servers or provide a single name')

    # if not particular server is given, use ALL
    global WORKBOOKNAME
    if vars(opts)['server'].lower() == 'all':
        WORKBOOKNAME = path.dirname(path.realpath(__file__)) + '/all_lpars_perfreport.xlsx'
        return BASELINE
    else:
        WORKBOOKNAME = path.dirname(path.realpath(__file__)) + '/' + vars(opts)['server'] + '_perfreport.xlsx'
        return eval("['" + (vars(opts)['server']) + "']")
# --------------------------------------------------------------- #


# --------------------------------------------------------------- #
def mkworkbook(servername, samples):
    """
    Purpose:
        To create the Workbook(excel file) with graphs using the data gathered from vmstat

    Parameters:
    """
    wb = Workbook()

    # --- 'Overall' Sheet
    ws = wb.worksheets[0]
    ws.title = servername
    ws.cell(row=1, column=1, value='Date')
    ws.cell(row=1, column=2, value='Average Busy')
    ws.cell(row=1, column=3, value='% of Samples above {}% Cpu Usage'.format(100 - TRESHOLDW))
    ws.cell(row=1, column=4, value='% of Samples above {}% Cpu Usage'.format(100 - TRESHOLDC))

    i = 1
    for date, average, warning, critical in samples:
        i = i + 1
        ws.cell(row=i, column=1, value=date)
        ws.cell(row=i, column=2, value=average)
        ws.cell(row=i, column=3, value=warning)
        ws.cell(row=i, column=4, value=critical)

    # --- Setting Chart Properties
    chart = LineChart()
    chart.title = '{} CPU Usage'.format(servername)
    chart.style = 3
    chart.x_axis.number_format = 'dd/mm'
    chart.x_axis.majorTimeUnit = "days"
    chart.height = 10
    chart.width = 26
    chart.legend.position = "t"
    chart.legend.layout = Layout(manualLayout=ManualLayout(yMode='edge', xMode='edge', h=0.1, w=0.8))
    chart.plot_area.layout = Layout(manualLayout=ManualLayout(yMode='edge', xMode='edge'))

    # --- Looping over Columns to build the Chart
    # columns Average, Warning and Critical
    for col in range(2, 5):
        values = Reference(ws, min_col=col, min_row=1, max_row=i)
        series = Series(values, title_from_data=True)  # creating the Serie
        chart.series.append(series)

    # Creating Trend
    chart.series[0].trendline = Trendline()

    # --- Setting Plot Area Format
    # Formatting Series
    chart.series[0].graphicalProperties.line = drawing.line.\
        LineProperties(solidFill=drawing.colors.ColorChoice(prstClr='green'))
    chart.series[1].graphicalProperties.line = drawing.line.\
        LineProperties(solidFill=drawing.colors.ColorChoice(prstClr='orange'))
    chart.series[2].graphicalProperties.line = drawing.line.\
        LineProperties(solidFill=drawing.colors.ColorChoice(prstClr='red'))

    # Formatting Trend Line
    chart.series[0].trendline.graphicalProperties = GraphicalProperties()
    chart.series[0].trendline.graphicalProperties.line.solidFill = drawing.colors.ColorChoice(prstClr='purple')

    # Setting the 'date' x-axis
    dates = Reference(ws, min_col=1, min_row=2, max_row=i)
    chart.set_categories(dates)

    # Adding the Chart
    ws.add_chart(chart, "A2")

    wb.save('{}/../{}.xlsx'.format(VMSTATLOCALDIR, servername))  # saving the workbook
    wb.close()
    print ('{} created successfully'.format(path.realpath('{}/../{}.xlsx'.format(VMSTATLOCALDIR, servername))))
# --------------------------------------------------------------- #
### END OF FUNCTIONS DECLARATION

### START OF CLASS DEFINITIONS
# --------------------------------------------------------------- #
class WorkBook(object):
    """
    WorkBook Factory. A Workbook is the excel file containing averages and the graphs.

    Parent:
    Attributes:
        userdict{} = The original OrderedDict generated by Ansible.
        attributes[]: A Dictionary containing the user attributes.
        servers[]: A list containing the servers the user is present
    """
# --------------------------------------------------------------- #
### END OF CLASS DEFINITIONS


### START OF MAIN PROGRAM
serverlist = parse_args()
overall = []
for server in serverlist:
    print('Generating reports for {} ...'.format(server))
    overall = eval(open(VMSTATLOCALDIR + '/' + server + '/' + server + '.list', 'r').read())

    mkworkbook(server, overall)
### END OF MAIN PROGRAM
