#!/usr/bin/python
# - Purpose:
#       To convert range of dates
# - Author:
#       Rudolf Wolter
# - Contact for questions and/or comments:
#       rudolf.wolter@kuehne-nagel.com
# - Parameters:
#       < accepted arguments>
# - Version Releases and modifications.
#       <versions history log>

### START OF MODULE IMPORTS
# --------------------------------------------------------------- #
from os import path, system
from datetime import time, datetime
from subprocess import Popen, PIPE
from collections import OrderedDict
from optparse import OptionParser
# --------------------------------------------------------------- #
### END OF MODULE IMPORTS

### START OF GLOBAL VARIABLES DECLARATION
# --------------------------------------------------------------- #
PEAKSTART = time(8, 00)
PEAKSTOP = time(20, 00)
TRESHOLDW = 20
TRESHOLDC = 8
INTERVAL = 6  # INTERVAL x 10 sec / 60 = Minutes
VMSTATSOURCEDIR = '/ib/dat/kn/statistic/vmstat'
VMSTATLOCALDIR = path.dirname(path.realpath(__file__)) + '/reports'
BASELINE = ['sindbad', 'ibaz', 'parisade', 'ibcomtest',
            'salomo', 'alibaba','maruf', 'ibedi1', 'ibedi2',
            'ibedi3','ibedi4', 'ibcom1', 'ibcom2', 'ibcom3']
# --------------------------------------------------------------- #
### END OF GLOBAL VARIABLES DECLARATION\

### START OF FUNCTIONS DECLARATION
# --------------------------------------------------------------- #
def parse_args():
    """
    Purpose:
        To parse the scripts given arguments and to generate a dictionary with the values.
    Returns:
        options: A Dictionary with all given, validated arguments.
    Parameters:
    """
    parser = OptionParser(usage='-h | -s [ ALL | servername ]')

    # Declaring Arguments
    parser.add_option("-s", "--server", dest="server",
                      help="ALL to retrieve from all servers or server name to retrieve from a singular server")

    (opts, pargs) = parser.parse_args()
    if not opts.server:
        parser.error('Server Name not given. Use ALL for all servers or provide a single name')

    # if not particular server is given, retrieve from ALL
    if vars(opts)['server'].lower() == 'all':
        return BASELINE
    else:
        return eval("['" + (vars(opts)['server']) + "']")
# --------------------------------------------------------------- #
# --------------------------------------------------------------- #
def retrieveFiles(server):
    """
    Purpose:
        To retrieve vmstat files from a server
    Returns:
        options: A Dictionary with all given, validated arguments.
    Parameters:
        server - Server where the files will be retrieved
    """
    print('Trying to retrieve Vmstat files from {} ...').format(server)
    cmd = "/usr/bin/rsync -avz {}:{}/*.dat* {}/{}/".format(server, VMSTATSOURCEDIR, VMSTATLOCALDIR, server)
    output = system(cmd)
    print('Success!')
    return output
# --------------------------------------------------------------- #

# --------------------------------------------------------------- #
def select_files(server, newerthan=31):
    """
    Purpose:
        To selects the vmstat files from a server that are newwe than 'newerthan'
    Returns:
        options: A Dictionary with all given, validated arguments.
    Parameters:
        server - in which server te files should be selected
        newerthan- files new than this will be selected. Default 31 days
    """
    print('Uncompressing any compressed files ...')
    cmd = 'find {}/{} -mtime -{} -type f -name "*.dat.gz" -exec  gzip -kfd {}'.format(VMSTATLOCALDIR, server, newerthan, "{} \;")
    system(cmd)
    print('Success!')

    print('Selecting Vmstat files newer than {} days for {} ...').format(newerthan, server)
    cmd = 'find {}/{} -mtime -{} -type f -name "*.dat"'.format(VMSTATLOCALDIR, server, newerthan)
    output = []
    for _file in Popen(cmd, stdin=PIPE, stdout=PIPE, shell=True).stdout.readlines():
        output.append(_file.replace('\n', ''))

    print('Success!')
    return output
# --------------------------------------------------------------- #
### END OF FUNCTIONS DECLARATION

### START OF CLASS DEFINITIONS
# --------------------------------------------------------------- #
# --------------------------------------------------------------- #
### END OF CLASS DEFINITIONS


### START OF MAIN PROGRAM
serverlist = parse_args()
days = OrderedDict()
for server in serverlist:
    print('Generating reports for {} ... It may take a while.'.format(server))
    overall = []
    retrieveFiles(server)
    vmstat_files = select_files(server)
    for vmstat_file in vmstat_files:
        pholder, srvname, d8 = path.basename(vmstat_file).strip('.dat').split('_')
        d8 = datetime.strptime(d8, '%Y%m%d')
        # Only considers Weekdays
        if d8.weekday() < 5:
            print('Processing {}'.format(vmstat_file))
            cmd = "grep ':' " + vmstat_file + " | egrep -v 'System configuration' | awk '{print $17, $NF}'"
            output = Popen(cmd, stdin=PIPE, stdout=PIPE, shell=True).stdout.readlines()
            samples = []
            customsamples = []
            customavg = []
            timestamps = []
            tsholdw = []
            tsholdc = []
            day = d8.strftime('%d-%m-%Y')
            days[day] = []

            for count, item in enumerate(output):
                idle, timestamp = item.split(' ')
                idle = int(idle)
                h, m, s = [int(x) for x in timestamp.strip().split(':')]
                timestamp = time(h, m, s)
                # Only consider Business Hours
                if PEAKSTART <= timestamp <= PEAKSTOP:
                    customsamples.append(idle)
                    if idle <= TRESHOLDW:
                        tsholdw.append((idle, timestamp.strftime('%H:%M:%S')))
                    if idle <= TRESHOLDC:
                        tsholdc.append((idle, timestamp.strftime('%H:%M:%S')))
                    if count % INTERVAL == 0:
                        cs = round(sum(customsamples, 0.00) / len(customsamples), 2)
                        samples.extend(customsamples)
                        days[day].append((timestamp.strftime('%H:%M:%S'), cs))
                        customsamples = []
            try:
                avgthshw = round(len(tsholdw) / round(len(samples), 2) * 100, 2)
                avgthshc = round(len(tsholdc) / round(len(samples), 2) * 100, 2)
                avgday = 100 - (round(sum(samples, 0.00) / len(samples), 2))
                overall.append((day, avgday, avgthshw, avgthshc))

            except ZeroDivisionError:
                print 'Vmstat data not found for file {}:'.format(file.strip())
    print overall
    listfile = open(VMSTATLOCALDIR + '/' + server + '/' + server + '.list', 'w')
    listfile.write(str(overall))
    listfile.close()
print('Success!')

### END OF MAIN PROGRAM
